$mapcontainer = $(".mapcontainer");
$mapcontainer.mapael({
    map: {
        name: "arabworld2",
        defaultArea: {
            attrs: {
                // fill: "#343434"
                fill: "#f0f0f0"
                , stroke: "#e0e0e0"
                , "stroke-width": 0.2
                , "stroke-linejoin": "round"
            }
            , attrsHover: {
                fill: '#f0f0f0',
                stroke: "#e0e0e0",
                animDuration: 400
            },
            // tooltip: {
            //     content: function () {
            //         return '<strong>' + state + '</strong>';
            //     }
            // },
            eventHandlers: {
                mouseover: function (e, id) {
                    state = id;
                }
            }
        }


        // defaultPlot: {
        //     size: 17,
        //     attrs: {
        //         //fill: Sing.colors['brand-warning'],
        //         stroke: "#fff",
        //         "stroke-width": 0.2,
        //         "stroke-linejoin": "round"
        //     },
        //     attrsHover: {
        //         "stroke-width": 0.1,
        //         animDuration: 100
        //     }
        // },
        // zoom: {
        //     enabled: false,
        //     step: 0.75
        // }
    },
    // Customize some areas of the map
    areas: {
        // "eg": {
        //     text: {content: "Morbihan", attrs: {"font-size": 10}},
        //     tooltip: {content: "<b>Morbihan</b> <br /> Bretagne"}
        // },
        "eg": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "ly": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "dz": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "ma": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "sd": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "ps": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "lb": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "tn": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "eh": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "jo": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "sy": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "iq": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "sa": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "qa": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "bh": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "kw": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "ae": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "om": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "ye": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "so": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "xs": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "dj": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "mr": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}},
        "hm": {attrs: {fill: "#006666"}, attrsHover: {fill: "#669900"}}
    }
});