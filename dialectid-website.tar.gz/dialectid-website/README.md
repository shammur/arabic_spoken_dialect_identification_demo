# dialectid-website
Web interface for QMDIS system developed as a collaboration between QCRI and MIT CSAIL
